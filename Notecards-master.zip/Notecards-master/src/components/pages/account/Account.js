import React from 'react';
import PageNotFinished from "../../reusable/page_not_finished/PageNotFinished";

const Account = () => {
  return <PageNotFinished />;
};

export default Account;