import React from 'react';
import PageNotFinished from "../../reusable/page_not_finished/PageNotFinished";

const CreateDeck = () => {
  return <PageNotFinished />;
};

export default CreateDeck;